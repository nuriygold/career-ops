## Application: Mercury | Senior Analyst, Compensation & People Analytics
**URL:** https://job-boards.greenhouse.io/mercury/jobs/5847980004
**PDF to upload:** output/cv-candidate-mercury-2026-04-09.pdf

---

### Cover Letter

Dear Hiring Team,

I want to build Mercury's people analytics practice. Not manage one that already exists, build it.

For the past year at Wellstar Health System, I've worked inside Total Rewards, turning messy HR data into dashboards and executive materials that drive real compensation and benefits decisions. I use Power BI, SQL, and PowerQuery daily. I build the reporting that connects workforce investments to ROI. Before that, I ran a $4.5M multi-institution program at Harvard Medical School, aligning 10+ stakeholders, managing sensitive budgets, and creating the decision frameworks that kept everything moving.

Thirteen years of program leadership taught me something specific: the best comp decisions come from clean data, honest analysis, and someone who can translate numbers into a story executives actually act on. That is exactly what I do.

What draws me to Mercury is the opportunity to go deep. I have broad experience across operations, program management, and Total Rewards analytics. Now I want to focus that energy on compensation strategy and people data at a company where those things genuinely matter. Mercury's growth stage, talent density, and commitment to building real infrastructure , not just patching spreadsheets, is exactly the environment where my skills compound fastest.

Practically, here is what I bring on day one: I can run market analyses in SQL and Power BI. I can build comp dashboards that finance and people teams both trust. I can sit in a room with a VP and walk them through pay equity data without oversimplifying or overcomplicating. And I can design the repeatable processes, merit cycle workflows, benchmarking cadences, stakeholder communication plans, that make a comp function scale.

I have managed DOE and defense client data at Ideagen DevonWay, so handling confidential compensation information is not new territory. Discretion is baseline for me.

I would welcome the chance to discuss how my Total Rewards analytics work and cross-functional program experience map to what you are building. Thank you for your time.

Aaliya Bashir

---

### Common Form Answers

**Why are you interested in this role?**
I have spent the past year inside Total Rewards at Wellstar, building dashboards and executive analytics that drive compensation and benefits decisions. This role at Mercury is the chance to go deeper, owning the full comp analytics cycle instead of supporting it alongside broader program work. Mercury's growth stage means I would be building infrastructure, not maintaining it. That is the work I want to do.

**Why Mercury?**
Mercury takes its people infrastructure seriously at a stage where most companies are still improvising. The fact that you are investing in a dedicated comp and people analytics role , not tacking it onto an HR generalist's plate, tells me you are building for scale. I want to be part of that. The fintech mission resonates too: I have spent my career making complex systems work for the people inside them.

**Salary expectations:**
$200,000+, depending on total compensation structure including equity. I am open to discussing the full package.

**Work authorization:**
U.S. citizen. No sponsorship required.

**Remote:**
Yes. Based in Atlanta, GA. Fully set up for remote work and available for periodic travel as needed.

**Additional information:**
Two things worth noting. First, my experience is broader than a typical Senior Analyst candidate. I have managed $4.5M budgets, led cross-functional teams, and operated in regulated environments (DOE, defense, healthcare). I see that as an asset, not a mismatch. It means I can partner with senior leaders from day one without a ramp-up period on stakeholder management. Second, I hold a PMP and CSM, which means the process design side of this role, building scalable merit cycle workflows, standing up repeatable analytics cadences, is something I have done across multiple industries. I am making a deliberate move deeper into compensation analytics, and Mercury is the right place to do that.

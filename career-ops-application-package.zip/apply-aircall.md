## Application: Aircall | HR Program Manager
**URL:** https://jobs.lever.co/aircall/78b597ac-a9f2-428f-a42c-96b97b5f5856
**PDF to upload:** output/cv-aaliya-bashir-aircall-2026-04-09.pdf

---

### Cover Letter

Dear Hiring Team,

I'm applying for the HR Program Manager role at Aircall. I currently lead Total Rewards analytics and labor optimization at Wellstar Health System, where I build the dashboards, executive presentations, and compensation data stories that drive people-program decisions across the enterprise. This is the exact domain your role operates in. I want to bring that skill set to a global tech company.

Two things stand out about my fit:

First, I know how to run complex programs across organizations that don't report to each other. At Harvard Medical School, I managed a $4.5M initiative spanning 10+ institutions with independent governance, budgets, and compliance requirements. I designed the operating rhythms, decision frameworks, and communication plans that kept the whole thing moving. That coordination challenge, aligning autonomous stakeholders around shared goals, mirrors what global HR program management looks like at a multinational like Aircall.

Second, I bring data discipline to HR work. I build Power BI and Tableau dashboards daily. I write SQL queries against large workforce datasets. I connect benefits utilization and compensation trends to business outcomes in language that executives act on. Most HR program managers run programs. I measure them.

On the tools side: I've implemented enterprise software for DoE and defense clients at Ideagen DevonWay, managing budgets up to $2.2M and increasing customer satisfaction by 25%. HRIS platforms like BambooHR are simpler than the systems I already work in. Picking one up is a configuration exercise, not a learning curve.

I'm drawn to Aircall because you're building a global People function at a company that's past the chaos stage but still scaling. That's where program management matters most, when you need repeatable systems, not just ad hoc fixes.

I'd welcome the chance to talk about how my Total Rewards and program leadership experience maps to what you're building.

Aaliya Bashir

---

### Common Form Answers

**Why are you interested in this role?**

I'm currently embedded in Total Rewards and compensation analytics at Wellstar Health System. This role lets me apply that same domain expertise, compensation, performance management, benefits, vendor management, at global scale in a tech environment. I've spent the last 13 years building the program management muscle (Harvard Medical School, $4.5M multi-institutional initiative; Ideagen DevonWay, enterprise software implementations up to $2.2M). Aircall is where those skills compound: a multinational company that needs structured, measurable HR programs, not just policies on paper.

**Why Aircall?**

Three reasons. One: Aircall is Series D+ with ~800 employees, past the early chaos but still building foundational people systems. That's the stage where strong program management has the highest leverage. Two: the global footprint means real complexity, multi-country compliance, cross-timezone coordination, diverse employment frameworks. I've done that coordination work across 10+ institutions at Harvard and across government/defense clients at Ideagen. Three: a cloud-native tech company values data and tooling. I build Power BI dashboards, write SQL, and connect people-program investments to ROI. That analytical approach fits a tech culture better than a traditional HR background would.

**Salary expectations:**

$200,000+ base, open to discussing total compensation including equity and benefits.

**Are you authorized to work in the US?**

Yes. U.S. citizen.

**Are you open to remote work?**

Yes. Based in Atlanta, GA. Open to remote, hybrid, or periodic travel. Available across U.S. time zones.

**Additional information:**

I hold a PMP and CSM certification, a Master of Public Administration from Augusta University, and a Graduate Certificate in Corporate Sustainability and Innovation from Harvard University. My current work at Wellstar puts me directly in the Total Rewards and benefits analytics space this role covers. I'm comfortable with ambiguity, multi-stakeholder environments, and building programs from scratch. I scaled a business from 2 to 7 properties ($14M in savings) and managed a team of 17 while improving customer satisfaction by 34%. Happy to share work samples or walk through specific program designs in conversation.

## Application: Midi Health | Director, Total Rewards & People Operations
**URL:** https://job-boards.greenhouse.io/midihealth/jobs/4662270005
**PDF to upload:** output/cv-aaliya-bashir-midi-health-2026-04-09.pdf

### Cover Letter

Dear Hiring Team,

I'm applying for the Director, Total Rewards & People Operations role at Midi Health. I currently work in Total Rewards at Wellstar Health System, where I build dashboards, executive presentations, and analytics that support compensation, benefits, and workforce decisions. This role is a strong match for the kind of scope I want next: owning Total Rewards strategy while also leading the operational systems behind it.

What makes me a fit is the mix of data discipline and program leadership I bring. At Wellstar, I translate fragmented people data into clear, decision-ready insights using Power BI, SQL, Tableau, and PowerQuery. At Harvard Medical School, I led a $4.5M initiative across 10+ institutions, managing governance, communications, budgets, and stakeholder alignment in a complex environment. That combination maps well to a role that needs both strategy and execution.

I also bring direct experience working in healthcare, which matters here. Midi's workforce mix, pace, and mission-driven environment feel very close to the kinds of operating challenges I already understand. I know how to work across hourly and salaried populations, how to communicate with leaders in regulated environments, and how to build programs that are practical, measurable, and scalable.

I do want to be transparent that I do not have CCP certification yet, but I do have a PMP, Certified ScrumMaster, and 13+ years of program leadership experience. I learn quickly, and I have been deliberately deepening my Total Rewards experience through daily work in the function at Wellstar.

Midi Health is exactly the kind of place where I could contribute immediately and grow into broader ownership. I'd welcome the chance to discuss how my background could support your Total Rewards and People Ops goals.

Best,
Aaliya Bashir

### Common Form Answers

**Why are you interested in this role?**
This is the right next step for me because it combines Total Rewards strategy, people operations leadership, and the operational rigor I already bring to analytics and program management. I want to own the function, not just support it.

**Why Midi Health?**
Midi is mission-driven, high-growth, and operating in a healthcare context I understand well. The combination of remote flexibility, meaningful ownership, and a strong compensation package makes it a compelling place to build.

**Salary expectations:**
$200,000+ base, open to discussing total compensation including equity and benefits.

**Are you authorized to work in the US?**
Yes. U.S. citizen.

**Are you open to remote work?**
Yes. Based in Atlanta, GA. Open to remote and periodic travel as needed.

**Additional information:**
I bring a PMP, Certified ScrumMaster, MPA, and Harvard Graduate Certificate in Corporate Sustainability and Innovation. My current Total Rewards work at Wellstar is centered on analytics, executive reporting, and cross-functional problem solving, and I’m excited to bring that to a Director-level role.

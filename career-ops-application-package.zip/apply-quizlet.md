## Application: Quizlet | Senior Manager, Total Rewards and Operations
**URL:** https://jobs.lever.co/quizlet-2/04d62262-1666-4736-bbc3-f102ca16313d
**PDF to upload:** output/cv-candidate-quizlet-2026-04-09.pdf

### Cover Letter

Dear Hiring Team,

I'm applying for the Senior Manager, Total Rewards and Operations role at Quizlet. I currently work in Total Rewards at Wellstar Health System, where I build the dashboards, presentations, and analytics that help leadership make decisions about benefits, workforce investment, and labor optimization.

What I bring that's different from a typical comp specialist: I'm a program manager who moved into Total Rewards on purpose. That means I don't just run compensation cycles. I build the systems, reporting, and stakeholder alignment that make them work. At Wellstar, I use Power BI, SQL, Tableau, and PowerQuery to turn fragmented people-program data into executive-ready insights. At Harvard Medical School, I led a $4.5M initiative across 10+ institutions, managing governance, communications, and political complexity at a scale most HR leaders never touch.

I want to be transparent about my gaps. I haven't administered equity programs (ISOs, NSOs, RSUs) or run Comp Committee presentations. My Total Rewards experience is roughly 15 months deep. But I've managed $2.2M program budgets, trained 17-person teams, and improved customer satisfaction by 34% at one organization and 25% at another. I learn domains fast because I already know how to build the operating infrastructure underneath them.

Quizlet's mission matters to me. A platform used by 60M+ learners deserves a Total Rewards function that attracts and retains the people who keep it running. I want to be the person who builds that.

I'd welcome a conversation about how my program management depth and analytics skills could complement the comp expertise you're looking for.

Best,
Aaliya Bashir

### Common Form Answers

**"Why are you interested in this role?"**
Total Rewards Program Manager is my target role. I moved into this function deliberately because it sits at the intersection of data, program management, and employee experience, my three strongest skills. This role at Quizlet offers the chance to own the full scope: comp strategy, benefits, people ops, and HRIS. I want to build, not just maintain.

**"Why Quizlet?"**
Sixty million learners use Quizlet. That kind of scale means the People team's work has real downstream impact on product quality, every good hire and every retained employee shows up in the learning experience. I also appreciate that this is a player-coach role managing a small team. I've managed teams of 17 and coordinated across 10+ institutions. I do my best work when I can build systems and develop people at the same time.

**"Salary expectations":** $200,000+

**"Are you authorized to work in the US?":** Yes, US citizen

**"Are you willing to relocate?":** Prefer remote, but open to discussing options.

**"Additional information":**
I hold a PMP and Certified ScrumMaster, an MPA from Augusta University, and a Harvard Graduate Certificate in Corporate Sustainability. My analytics stack includes Power BI, Tableau, SQL, Excel, and PowerQuery. I've managed budgets up to $4.5M and programs across 10+ institutional stakeholders. Currently deepening comp-specific expertise through my daily Total Rewards work at Wellstar.

## Application: Dandy | Benefits Manager
**URL:** https://jobs.ashbyhq.com/dandy/88353677-ee24-4af8-a805-d9082a28c987
**PDF to upload:** output/cv-aaliya-bashir-dandy-2026-04-09.pdf

### Cover Letter

Dear Hiring Team,

I'm applying for the Benefits Manager role at Dandy. I work in Total Rewards at Wellstar Health System today, where I build the analytics and dashboards that connect benefits and workforce program data to executive decisions. I want to move from analyzing benefits to owning them, and a builder role at a high-growth company is the right next step.

At Wellstar, I use Power BI, SQL, Tableau, and PowerQuery to synthesize benefits utilization, cost data, and employee experience metrics into dashboards that leadership acts on. I understand how Total Rewards programs work from the data side. What I'm looking to do is own the full stack: plan design, vendor management, open enrollment, compliance, and strategy.

My program management background is what makes this pivot realistic. At Harvard Medical School, I ran a $4.5M initiative across 10+ institutions, governance, communications, timelines, political complexity. Open enrollment is a different domain, but the operational muscle is the same: tight deadlines, multiple stakeholders, clear communications, zero room for error. At Ideagen DevonWay, I managed vendor relationships and client delivery for DOE and defense clients ($245K to $2.2M), increasing satisfaction by 25%. At Warrior Body Spa, I managed a 17-person team and improved satisfaction by 34% in six months.

I want to be honest: I haven't owned ERISA/ACA compliance or run open enrollment cycles directly. But I've worked in regulated environments my entire career, healthcare, defense, academic medicine, and I pick up compliance frameworks quickly. My PMP training reinforces that discipline.

Dandy is building something real in a $200B+ market, and the Benefits Manager role is about building the Total Rewards function from scratch. That's exactly where my skills, program management, analytics, vendor management, cross-functional leadership, create the most value.

Best,
Aaliya Bashir

### Common Form Answers

**"Why are you interested in this role?"**
I work in Total Rewards today, building the dashboards and analytics that inform benefits decisions. This role lets me own the function end-to-end: plan design, vendor negotiation, open enrollment, compliance. I've managed $4.5M programs and coordinated across 10+ institutional stakeholders. Building a Total Rewards function from scratch at a high-growth company is the challenge I'm looking for.

**"Why Dandy?"**
Dandy is tackling a $200B+ market with real technology, and you need someone to build the benefits function , not just maintain one. I've spent my career building structure where there wasn't any: operations at a growing business, program infrastructure at Harvard, reporting systems at Wellstar. A builder role at a company that's scaling fast is where I do my best work.

**"Salary expectations":** $200,000+

**"Are you authorized to work in the US?":** Yes, US citizen

**"Are you willing to relocate?":** Prefer remote (role is listed as USA Remote).

**"Additional information":**
PMP and Certified ScrumMaster. MPA from Augusta University, Harvard Graduate Certificate in Corporate Sustainability. Currently in Total Rewards at Wellstar Health System, working with benefits utilization data, workforce analytics, and executive reporting daily. Strong vendor management experience from managing DOE and defense client implementations at Ideagen DevonWay.

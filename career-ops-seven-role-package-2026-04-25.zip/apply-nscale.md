## Application: Nscale | Director, People Partnering - AI Infrastructure (US)
**URL:** https://job-boards.greenhouse.io/nscaleoperationsukltd/jobs/4799818101
**PDF to upload:** output/cv-aaliya-bashir-nscale-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Director, People Partnering - AI Infrastructure (US) role at Nscale. My background fits a distributed, fast-moving technology organization that needs people partnering grounded in data and process.

People operations and strategic program leader with 13+ years helping teams translate data, process, and stakeholder needs into action. Current work at Wellstar combines executive storytelling, dashboard development, and labor optimization support across benefits and compensation. Well suited to people partnering roles that require structure, clarity, and strong cross-functional execution in a fast-moving environment.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

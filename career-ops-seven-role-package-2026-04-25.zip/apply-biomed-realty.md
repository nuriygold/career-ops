## Application: BioMed Realty | Director, Total Rewards
**URL:** https://job-boards.greenhouse.io/biomedrealty/jobs/4665638006
**PDF to upload:** output/cv-aaliya-bashir-biomed-realty-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Director, Total Rewards role at BioMed Realty. My background fits a hands-on role that needs compensation expertise, HR systems rigor, and actionable leadership reporting.

Total rewards leader with deep experience translating data into practical workforce decisions. Currently supports Total Rewards analytics at Wellstar Health System, building dashboards and narrative for compensation, benefits, and labor optimization work. Brings a process-oriented approach, solid executive communication, and a track record of improving reporting, team performance, and operational clarity.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

## Application: Iovance Biotherapeutics | Senior Director, Total Rewards and Operations
**URL:** https://job-boards.greenhouse.io/iovancebiotherapeutics/jobs/5157424008
**PDF to upload:** output/cv-aaliya-bashir-iovance-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Senior Director, Total Rewards and Operations role at Iovance Biotherapeutics. My background fits a growth environment where total rewards, HR operations, and system improvement need to stay tightly aligned.

Total rewards and operations leader with 13+ years of experience driving structured, executive-ready people programs. At Wellstar, supports Total Rewards and labor optimization with dashboards, analysis, and cross-functional coordination across benefits, compensation, and workforce planning. Combines rigorous execution, stakeholder management, and strong business storytelling in complex environments.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

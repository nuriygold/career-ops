## Application: Formation Bio | Director, People Operations & Total Rewards
**URL:** https://job-boards.greenhouse.io/formationbio/jobs/7738920
**PDF to upload:** output/cv-aaliya-bashir-formation-bio-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Director, People Operations & Total Rewards role at Formation Bio. My background fits a high-growth, tech-enabled environment that needs strong people operations, clean process, and credible total rewards leadership.

People operations and total rewards program leader with a background in executive storytelling, workflow design, and data-driven decision support. Currently owns Total Rewards analytics work at Wellstar, where benefits, compensation, and labor optimization reporting are translated into clear next steps for leadership. Brings strong program discipline, stakeholder alignment, and a calm operating style in ambiguous environments.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

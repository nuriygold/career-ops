## Application: Curaleaf | Vice President, Total Rewards
**URL:** https://job-boards.greenhouse.io/curaleaf/jobs/8439522002
**PDF to upload:** output/cv-aaliya-bashir-curaleaf-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Vice President, Total Rewards role at Curaleaf. My background fits a fast-paced, high-accountability environment that needs executive-facing rewards strategy and strong operating judgment.

Senior people leader with 13+ years of experience in operations, program management, and total rewards analytics. At Wellstar, supports enterprise Total Rewards and labor optimization with dashboards, leadership storytelling, and cross-functional coordination. Brings the operating discipline, stakeholder maturity, and practical problem-solving needed for a large, regulated, multi-site environment.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

## Application: ProShares | Director, HR Operations & Total Rewards
**URL:** https://job-boards.greenhouse.io/proshares/jobs/5857594004
**PDF to upload:** output/cv-aaliya-bashir-proshares-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Director, HR Operations & Total Rewards role at ProShares. My background fits a lean HR environment that needs disciplined HR operations, reporting, and total rewards execution across the employee lifecycle.

HR operations and total rewards leader with 13+ years of experience improving workforce programs, reporting, and operating cadence. At Wellstar Health System, supports Total Rewards analytics and labor optimization by translating benefits and compensation data into leadership-ready insights. Known for building clean processes, partnering across functions, and making complex people data usable for executives.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir

## Application: Peregrine Technologies | Senior Director, Total Rewards
**URL:** https://job-boards.greenhouse.io/peregrinetechnologies/jobs/4671594005
**PDF to upload:** output/cv-aaliya-bashir-peregrine-2026-04-25.pdf

### Cover Letter

Dear Hiring Team,

I am writing to apply for the Senior Director, Total Rewards role at Peregrine Technologies. My background in Total Rewards analytics, labor optimization, and executive storytelling fits a build-and-scale environment where compensation, benefits, people operations, HR systems, and workforce analytics must work together.

Senior total rewards and operations leader with 13+ years turning complex workforce data into executive decisions. Currently supports Total Rewards analytics and labor optimization at Wellstar Health System, building dashboards and operating rhythms that connect benefits, compensation, and employee experience to business outcomes. Brings strong executive storytelling, process design, and cross-functional leadership across analytics-heavy programs.

I would welcome the opportunity to contribute this combination of analytics, operations, and executive communication to your team.

Best,
Aaliya Bashir
